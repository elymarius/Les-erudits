<?php
// Configuration base de données InfoProd
define('DB_HOST', 'localhost');
define('DB_NAME', 'infoprod');
define('DB_USER', 'root');
define('DB_PASS', '');

// Connexion PDO
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch(PDOException $e) {
    die("Erreur connexion BDD : " . $e->getMessage());
}

// Démarrer la session
session_start();

// Fonction vérification authentification
function estConnecte() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

// Fonction vérification rôle
function estAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Fonction vérification rôle secrétariat
function estSecretariat() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'secretariat';
}

// Fonction redirection si non connecté
function requireLogin() {
    if (!estConnecte()) {
        header('Location: login.php');
        exit;
    }
}

// Fonction redirection si non admin
function requireAdmin() {
    requireLogin();
    if (!estAdmin()) {
        header('Location: dashboard.php');
        exit;
    }
}

// Fonction ajout log
function ajouterLog($pdo, $action, $description = '') {
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("INSERT INTO logs (utilisateur_id, action, description) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $action, $description]);
    }
}
?>