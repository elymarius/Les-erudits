-- ==============================================
-- InfoProd V2 - Base de données SQL
-- BTS CIEL 2026 - Étudiant 1 : Le flo
-- ==============================================

-- Création base de données
CREATE DATABASE IF NOT EXISTS infoprod CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE infoprod;

-- 1. Table utilisateurs (Admin + Secrétariat)
CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    role ENUM('admin', 'secretariat') NOT NULL,
    email VARCHAR(100),
    actif TINYINT(1) DEFAULT 1,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    derniere_connexion TIMESTAMP NULL
) ENGINE=InnoDB;

-- 2. Table gabarits (modèles d'affichage)
CREATE TABLE gabarits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    contenu_html TEXT NOT NULL,
    style_css TEXT,
    actif TINYINT(1) DEFAULT 1,
    ordre_affichage INT DEFAULT 0,
    duree_affichage INT DEFAULT 10 COMMENT 'en secondes',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    cree_par INT,
    FOREIGN KEY (cree_par) REFERENCES utilisateurs(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 3. Table données capteurs
CREATE TABLE capteurs_donnees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_capteur ENUM('temperature', 'presence', 'energie') NOT NULL,
    valeur DECIMAL(10,2) NOT NULL,
    unite VARCHAR(20),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    gabarit_id INT,
    FOREIGN KEY (gabarit_id) REFERENCES gabarits(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 4. Table logs
CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ==============================================
-- DONNÉES DE TEST
-- ==============================================

-- Comptes utilisateurs
INSERT INTO utilisateurs (username, password, nom, prenom, role, email) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrateur', 'InfoProd', 'admin', 'admin@infoprod.local'),
('secretariat', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Secrétariat', 'Lycée', 'secretariat', 'secretariat@infoprod.local');

-- Mot de passe : infoprod2026 pour les 2 comptes

-- Gabarits exemples
INSERT INTO gabarits (nom, description, contenu_html, style_css, ordre_affichage, duree_affichage, cree_par) VALUES
('Accueil Lycée', 'Message de bienvenue', '<div class="welcome"><h1>Bienvenue au Lycée</h1><p>InfoProd - Affichage dynamique</p><div id="temp">--°C</div></div>', 'body{background:#1e3a8a;color:#fff;font-family:Arial;text-align:center;padding:50px;}h1{font-size:3rem;margin-bottom:20px;}#temp{font-size:2rem;background:rgba(255,255,255,0.2);padding:10px;border-radius:10px;margin-top:20px;}', 1, 10, 1),
('Température', 'Affichage capteurs', '<div class="temp"><h2>🌡️ Température</h2><div class="value">--°C</div><p>Salle informatique</p></div>', 'body{background:#059669;color:#fff;font-family:Arial;text-align:center;padding:50px;}.value{font-size:5rem;font-weight:bold;margin:20px 0;background:rgba(255,255,255,0.2);padding:20px;border-radius:20px;}', 2, 15, 1),
('Annonces', 'Messages importants', '<div class="annonces"><h2>📢 Annonces</h2><ul><li>Réunion parents : 15 mars 18h</li><li>Examens BTS : 5-12 mai</li><li>Portes ouvertes : 20 avril 10h</li></ul></div>', 'body{background:#dc2626;color:#fff;font-family:Arial;padding:50px;}ul{text-align:left;font-size:1.5rem;list-style:none;margin-top:30px;}li{margin:15px 0;padding-left:30px;background:rgba(255,255,255,0.1);border-radius:5px;padding:10px;}', 3, 20, 1);

-- ==============================================
-- FIN DE L'IMPORTATION
-- ==============================================
-- Test : http://localhost/infoprod/login.php
-- Admin : admin / infoprod2026
-- Secrétariat : secretariat / infoprod2026