<?php
// index.php - Page d'accueil publique InfoProd (accessible sans connexion)
// Rotation automatique des gabarits actifs

require_once 'config.php';

// Récupération des gabarits actifs (ordre d'affichage)
try {
    $stmt = $pdo->query("
        SELECT * FROM gabarits 
        WHERE actif = 1 
        ORDER BY ordre_affichage ASC, date_creation ASC
    ");
    $gabarits = $stmt->fetchAll();
} catch(PDOException $e) {
    $gabarits = [];
    $erreur = "Base de données non disponible.";
}

// Sélection du gabarit actuel (basé sur GET ou session)
$currentIndex = isset($_GET['gabarit']) ? (int)$_GET['gabarit'] : 0;
if ($currentIndex >= count($gabarits)) $currentIndex = 0;

$currentGabarit = $gabarits[$currentIndex] ?? null;

// Auto-rotation (JavaScript)
$nextGabaritIndex = ($currentIndex + 1) % count($gabarits);
$dureeAffichage = $currentGabarit['duree_affichage'] ?? 10;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InfoProd - Affichage dynamique</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            height: 100vh;
            overflow: hidden;
            background: #000;
            position: relative;
        }
        .gabarit-container {
            width: 100%;
            height: 100%;
            position: relative;
        }
        .gabarit {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }
        .gabarit.active {
            opacity: 1;
        }
        .gabarit-info {
            position: absolute;
            bottom: 20px;
            right: 20px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        .status-indicator {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 20px;
            height: 20px;
            background: #10b981;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(16,185,129,0.7); }
            70% { box-shadow: 0 0 0 10px rgba(16,185,129,0); }
            100% { box-shadow: 0 0 0 0 rgba(16,185,129,0); }
        }
        .admin-link {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(102,126,234,0.9);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: background 0.3s;
        }
        .admin-link:hover {
            background: rgba(102,126,234,1);
        }
    </style>
</head>
<body>
    <div class="status-indicator"></div>
    <a href="login.php" class="admin-link">🔧 Admin</a>

    <div class="gabarit-container">
        <?php if ($currentGabarit): ?>
            <div class="gabarit active" id="gabarit-<?= $currentIndex ?>">
                <?= $currentGabarit['contenu_html'] ?>
            </div>
        <?php else: ?>
            <div class="gabarit active">
                <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;color:#666;">
                    <h1 style="font-size:3rem;margin-bottom:20px;">📺 InfoProd</h1>
                    <p>Aucun gabarit actif<br>Configuration en cours...</p>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($gabarits)): ?>
    <script>
        const totalGabarits = <?= count($gabarits) ?>;
        let currentGabarit = <?= $currentIndex ?>;
        const duree = <?= $dureeAffichage ?> * 1000; // en ms

        function changerGabarit() {
            // Cacher tous les gabarits
            document.querySelectorAll('.gabarit').forEach(g => g.classList.remove('active'));

            // Activer le suivant
            currentGabarit = (currentGabarit + 1) % totalGabarits;
            const nextGabarit = document.getElementById('gabarit-' + currentGabarit);
            if (nextGabarit) {
                nextGabarit.classList.add('active');
            }

            // Changement automatique
            setTimeout(changerGabarit, duree);
        }

        // Démarrer rotation après délai initial
        setTimeout(changerGabarit, duree);
    </script>
    <?php endif; ?>
</body>
</html>