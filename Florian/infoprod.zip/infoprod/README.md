# InfoProd V2 - BTS CIEL 2026

## Installation (5 min)

1. Copie les fichiers dans `C:\xampp\htdocs\infoprod\`
2. Démarre Apache + MySQL dans XAMPP
3. phpMyAdmin → Nouvelle BDD "infoprod" → Importe `infoprod_database.sql`
4. http://localhost/infoprod/login.php

**Comptes** :
- Admin : admin / infoprod2026
- Secrétariat : secretariat / infoprod2026

## Répartition tâches
**Étudiant 1** : Interface + CRUD gabarits
**Étudiant 2** : BDD + Capteurs IoT
